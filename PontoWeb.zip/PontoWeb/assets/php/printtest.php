
document.getElementById("cadastrarempresa").onclick = function() {abrircadastroempresa()};

function abrircadastroempresa() {
    document.getElementById("alinhamentoempresa2").classList.toggle("abrirempresa");
}