function remover() {
  var element = document.getElementById("turnoempresa");
  element.classList.add("hide");
}




function ocultar() {
    var element = document.getElementById("turnoempresa");
    element.classList.add("hide");
  }
  
  function mostrar() {
    var element = document.getElementById("turnoempresa");
    element.classList.remove("hide");
  }