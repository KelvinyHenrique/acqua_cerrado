document.getElementById("botaoabrir").onclick = function() {abrirrelatorioempresa()};

function abrirrelatorioempresa() {
    document.getElementById("relatoriofunc2").classList.toggle("relatoriovisivel");
}